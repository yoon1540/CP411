/*
 * menu.hpp
 *
 *  Created on: Oct 3, 2023
 *      Author: andre
 */

#ifndef MENU_HPP_
#define MENU_HPP_
#include <GL/glut.h>


void menuInit();

#endif /* MENU_HPP_ */
